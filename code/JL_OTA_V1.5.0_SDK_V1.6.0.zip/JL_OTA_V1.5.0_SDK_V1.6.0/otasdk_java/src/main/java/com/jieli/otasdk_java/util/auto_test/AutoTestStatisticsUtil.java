package com.jieli.otasdk_java.util.auto_test;

/**
 * @ClassName: AutoTestStatisticsUtil
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2022/2/21 14:12
 */
public class AutoTestStatisticsUtil {
    public int testSum = 0;
    public int currentCount = 0;

    public void clear() {
        testSum = 0;
        currentCount = 0;
    }
}
