package com.jieli.otasdk_java.util.auto_test;

/**
 * @ClassName: TestTaskFinishListener
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2022/2/21 14:15
 */
public interface TestTaskFinishListener {
    public void onFinish();
}
